rm(list=ls())

library(tm)
library(stringr)
library(ggplot2)
library(tokenizers)
library(wordcloud)


con <- file("usa.txt", "r", blocking = FALSE)
txt1 <- readLines(con)
close(con)  
loc<-grep("[[0-9]]",txt1)
loc1<-loc+3
loc2<-loc[-1]-1
loc2<-c(loc2,length(txt1))
nspeech=length(loc1)

sname=txt1[loc+1]

add =list() 
all_txt=""
for (i in 1:nspeech)
{ 
  ind_add=txt1[loc1[i]:loc2[i]]
  add[[i]]=paste(ind_add,collapse=" ")
  all_txt<-paste(all_txt,ind_add)
}



################ For all address  #################
add_all_to=unlist(tokenize_words(all_txt))
t_all=table(add_all_to)
wordcloud(words = names(t_all), freq = t_all, scale=c(8,.3),min.freq = 100, colors=brewer.pal(8, "Dark2"))

add_all_st= removeWords(all_txt,stopwords("english"))
add_all_to_st=unlist(tokenize_words(add_all_st))
t_all_st=table(add_all_to_st)
wordcloud(words = names(t_all_st), freq = t_all_st, scale=c(5,0.3),min.freq = 200, colors=brewer.pal(8, "Dark2"))

############### Comparison among presidents ########################

add_v<-as.matrix(add)
add_r_stop<-lapply(add,removeWords,stopwords("english"))
add_v_rstop<-as.matrix(add_r_stop)
df_t=data.frame(president=sname,address=add_v,address_r=add_v_rstop)
df_t$n_words=count_words(add_v_rstop)

add_to=tokenize_words(add_v_rstop)


tt1<-lapply(add_to,table)
tt2<-lapply(tt1,sort, decreasing=T)

p1_freq=tt2[[58]]
p2_freq=tt2[[56]]

nf <- layout(matrix(c(1,2,3,4),2,2,byrow = F), c(4,4), c(0.5,4), F)
layout.show(nf)
par(mar=rep(0, 4))
plot.new()
text(x=0.5, y=0.1, df_t$president[58])
wordcloud(words = names(tt2[[58]]), freq = tt2[[58]], scale=c(8,.3),min.freq = 3, colors=brewer.pal(8, "Dark2"))

plot.new()
text(x=0.5, y=0.1, df_t$president[3])
wordcloud(words = names(tt2[[51]]), freq = tt2[[51]], scale=c(8,.03),min.freq = 3, colors=brewer.pal(8, "Dark2"))


combine<-c(df_t$address[[56]],df_t$address[[58]])
corp = VCorpus(VectorSource(combine))

corp <- tm_map(corp, removePunctuation)
corp <- tm_map(corp, content_transformer(tolower))
corp <- tm_map(corp, removeNumbers)
corp <- tm_map(corp, function(x)removeWords(x,stopwords()))
term.matrix <- TermDocumentMatrix(corp)
term.matrix <- as.matrix(term.matrix)
colnames(term.matrix) <- df_t$president[c(56,58)]
comparison.cloud(term.matrix,max.words=100,random.order=FALSE,title.size=1)
commonality.cloud(term.matrix,max.words=100,random.order=FALSE)


##############################







t2<-table(add_t[[58]])
dim(t2)
tt2<-sort(t2,decreasing=T)
tt2[1:100]











#=============================================================

t1<-scan("psysoc.txt", what="character",sep=c(".","\n","?"))
txt<-t1[t1 !=""]
txt<-tolower(txt)
# txt.w<-strsplit(txt,"\\W")

dframe<-data.frame(txt,stringAsFactors = FALSE)
corpus<-Corpus(VectorSource(dframe$txt))
corpus<-tm_map(corpus,removePunctuation)
corpus<-tm_map(corpus, function (x) removeWords(x, stopwords("english")))
corpus<-tm_map(corpus,stemDocument,language="english")
inspect(corpus)

td<-TermDocumentMatrix(corpus)
check<-which(rowSums(as.matrix(td))>1)
td2<-(td[check,])

LSA<-lsa(td,dim=2)
# wd<-LSA$tk
# st<-LSA$dk
# mg<-LSA$sk
rmat<-LSA$tk%*%diag(LSA$sk)%*%t(LSA$dk)
# sum(abs(as.matrix(td)-rmat))

P<-LSA$tk%*%diag(LSA$sk)
gdf<-data.frame(P)
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text()+xlim(c(0,1.1))
sim1<-cosine(t(wd))
write.csv(sim1,file="t.csv")

t<-which(LSA$X1>6)

P<-LSA$dk%*%diag(LSA$sk)
sub<-c(rep(1,13), rep(2,12))
gdf<-data.frame(sub,P)
ggplot(gdf)+aes(x=X1,y=X2,color=sub,label=rownames(gdf))+geom_text()


########### remove sparce words ###################
LSA<-lsa(td2,dim=2)
# wd<-LSA$tk
# st<-LSA$dk
# mg<-LSA$sk
P<-LSA$tk%*%diag(LSA$sk)
gdf<-data.frame(P)
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text()
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text(size=6)+xlim(-2,0)+ylim(-0.5,2.3)


P<-LSA$dk%*%diag(LSA$sk)
sub<-c(rep(1,13), rep(2,12))
gdf<-data.frame(sub,P)
ggplot(gdf)+aes(x=X1,y=X2,color=sub,label=rownames(gdf))+geom_text()


######################################

dtmo1 <- DocumentTermMatrix(corpus, control = list(wordLengths=c(2,Inf), weighting=weightTf))
dtmo2 <- removeSparseTerms(dtmo1, sparse=0.85)
dtm <- dtmo2

rowTotals <- apply(dtm, 1, sum)
dtm2 <- dtm[rowTotals>0,]
dtm_LDA <- LDA(dtm2, 2)



#lda.collapsed.gibbs.sampler(td2, 3,vocab)



