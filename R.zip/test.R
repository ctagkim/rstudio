rm(list=ls())
options(encoding = 'UTF-8') 
#library(installr)
#install.java(version = 11, page_with_download_url = "http://jdk.java.net/java-se-ri/", path = "D:/java")
#install.packages("KoNLP")

Sys.setenv(JAVA_HOME="D:\\java\\jdk-11")



Sys.setlocale("LC_ALL", "korean")

library(readtext)
library(tm)
library(stringr)
library(ggplot2)
library(tokenizers)
library(wordcloud)
library(KoNLP)
library(RColorBrewer)

useNIADic(which_dic = c("woorimalsam", "insighter"), category_dic_nms = "", backup = F)

#useSejongDic()
txt <- readtext("test.txt")

txt0<-strsplit(txt$text,"\n")
txt1=txt0[[1]]

txt1<-gsub('[~!@#$%^&*()_+=?\'\"]<>',' ',txt1)
txt1<-gsub('(「|」|『|』|‘|’|“|”|\')','', txt1)

loc<-grep("[[0-9]]",txt1)
sname=txt1[loc+1]
loc1<-loc+3
loc2<-loc[-1]-1
loc2<-c(loc2,length(txt1))



nspeech=length(loc1)
add =list() 
all_txt=""
for (i in 1:nspeech)
{ 
  ind_add=txt1[loc1[i]:loc2[i]]
  add[[i]]=paste(ind_add,collapse=" ")
}

speech_len=nchar(add)

library(psych)
describe(speech_len,skew=F)

sname[which.max(speech_len)]
sname[which.min(speech_len)]

#########################

content_word <-function(h_txt,stopw){
    
    tmp <- KoNLP::SimplePos22(h_txt)
    tmp <- unlist(tmp)
    names(tmp) <- NULL
    tmp <- lapply(tmp, function(x) strsplit(x, split="[:+]"))
    tmp <- unlist(tmp)
    #tmp <- strsplit(tmp, " ")
    #tmp <- unlist(tmp)

    content=grep("(PV|PA|MM|MA|NC|NQ|NB)", tmp)
    tmp<-tmp[content]
    tmp<-gsub("(/PV|/PA)","다",tmp)
    tmp<-gsub("(/MM|/MA|/NC|/NQ|/NB)","",tmp)
    tmp<-gsub(paste(stopw,collapse="|"),"",tmp)
    tmp<-removeWords(tmp,stopw)
    tmp<-tmp[-which(tmp=="")]    
    ret=tmp
    return(ret)
}    
#####################################################
mystopwords <- c("것","하다","있다","되다","이","그리고","그러나","그","것임니다")
stopw=mystopwords
txt <- readtext("testm.txt")

txt0<-strsplit(txt$text,"\n")
txt1=txt0[[1]]

txt1<-gsub('[~!@#$%^&*()_+=?\'\"]<>',' ',txt1)
txt1<-gsub('(「|」|『|』|‘|’|“|”|\')','', txt1)

add_test=paste(txt1,collapse=" ")
content_word(add[11],mystopwords)

h_txt=add_test

tmp<-lapply(add,content_word,mystopwords)

address <-cbind(tmp)
df<-data.frame(address)
names(df)="address"
df$president=sname

################ For all address  ################
add_all_to=unlist(address)
t_all=table(add_all_to)

stable=sort(t_all,decreasing = T)[1:20]
gdf<-data.frame(words=stable)
wordcloud(words = names(t_all), freq = t_all, min.freq = 20, random.color=T,colors=brewer.pal(8, "Dark2"))
ggplot(data=gdf)+aes(x=words.add_all_to,y=words.Freq)+geom_bar(stat="identity")

####################################################
## TD MATRIX

corp = VCorpus(VectorSource(address))
corp <- tm_map(corp, removeWords, mystopwords)
td <- TermDocumentMatrix(corp)
inspect(td)

###########################################################
findFreqTerms(td,lowfreq=10)
############### Comparison among presidents ########################


tt1<-lapply(address,table)
tt2<-lapply(tt1,sort, decreasing=T)

comp1=16
comp2=19

p1_freq=tt2[[comp1]]
p2_freq=tt2[[comp2]]

nf <- layout(matrix(c(1,2,3,4),2,2,byrow = F), c(4,4), c(0.5,4), F)
layout.show(nf)
par(mar=rep(0, 4))
plot.new()
text(x=0.5, y=0.1, df$president[comp1])
wordcloud(words = names(tt2[[comp1]]), freq = tt2[[comp1]], min.freq = 3, colors=brewer.pal(8, "Dark2"))

plot.new()
text(x=0.5, y=0.1, df$president[comp2])
wordcloud(words = names(tt2[[comp2]]), freq = tt2[[comp2]], min.freq = 3, colors=brewer.pal(8, "Dark2"))


par(mfrow = c(1,1))

combine<-list(df$address[[comp1]],df$address[[comp2]])

corp = VCorpus(VectorSource(combine))
td2 <- TermDocumentMatrix(corp)
term.matrix <- as.matrix(td2)
colnames(term.matrix) <- df$president[c(comp1,comp2)]
comparison.cloud(term.matrix,max.words=50,random.order=FALSE,title.size=1)
commonality.cloud(term.matrix,max.words=50,random.order=FALSE)


library(lsa)
LSA<-lsa(td,dim=10)
wd<-LSA$tk
st<-LSA$dk
mg<-LSA$sk
rmat<-LSA$tk%*%diag(LSA$sk)%*%t(LSA$dk)
# sum(abs(as.matrix(td)-rmat))

#P<-LSA$tk%*%diag(LSA$sk)
Q<-t(diag(LSA$sk)%*%t(LSA$dk))
gdf<-data.frame(Q)
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_text()
sim1<-cosine(t(st))
write.csv(sim1,file="t.csv")

t<-which(LSA$X1>6)

P<-LSA$dk%*%diag(LSA$sk)
sub<-c(rep(1,12), rep(2,7))
gdf<-data.frame(sub,P)
ggplot(gdf)+aes(x=X1,y=X2,color=sub,label=rownames(gdf))+geom_text()


########### remove sparce words ###################
LSA<-lsa(td2,dim=2)
# wd<-LSA$tk
# st<-LSA$dk
# mg<-LSA$sk
P<-LSA$tk%*%diag(LSA$sk)
gdf<-data.frame(P)
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text()
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text(size=6)+xlim(-2,0)+ylim(-0.5,2.3)


P<-LSA$dk%*%diag(LSA$sk)
sub<-c(rep(1,13), rep(2,12))
gdf<-data.frame(sub,P)
ggplot(gdf)+aes(x=X1,y=X2,color=sub,label=rownames(gdf))+geom_text()


######################################

d <- dist(t(as.matrix(td)), method = "euclidean") # distance matrix
fit <- hclust(d, method="ward") 
plot(fit) # display dendogram
groups <- cutree(fit, k=3) # cut tree into 5 clusters
# draw dendogram with red borders around the 5 clusters 
rect.hclust(fit, k=3, border="red")
















dtmo1 <- DocumentTermMatrix(corpus, control = list(wordLengths=c(2,Inf), weighting=weightTf))
dtmo2 <- removeSparseTerms(dtmo1, sparse=0.85)
dtm <- dtmo2

rowTotals <- apply(dtm, 1, sum)
dtm2 <- dtm[rowTotals>0,]
dtm_LDA <- LDA(dtm2, 2)



#lda.collapsed.gibbs.sampler(td2, 3,vocab)



