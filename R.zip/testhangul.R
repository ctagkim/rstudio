library(devtools)
install_github('haven-jeon/NIADic/NIADic', build_vignettes = TRUE)




rm(list=ls())
#library(installr)
#install.java(version = 11, page_with_download_url = "http://jdk.java.net/java-se-ri/", path = "D:/java")
#install.packages("KoNLP")

Sys.setenv(JAVA_HOME="D:\\java\\jdk-11")




library(tm)
library(stringr)
library(ggplot2)
library(tokenizers)
library(wordcloud)
library(KoNLP)
library(tidyverse)


useSejongDic()


sent<-"아름다운 사람입니다. 사랑하는 사람이  아닙니다"

Encoding(sent)

t<-SimplePos09(sent)
mutate(t)
