rm(list=ls())
options(encoding = 'UTF-8') 
#library(installr)
#install.java(version = 11, page_with_download_url = "http://jdk.java.net/java-se-ri/", path = "D:/java")
#install.packages("KoNLP")

Sys.setenv(JAVA_HOME="D:\\java\\jdk-11")


library(readtext)
library(tm)
library(stringr)
library(ggplot2)
library(tokenizers)
library(wordcloud)
library(KoNLP)

#useNIADic(which_dic = c("woorimalsam", "insighter"), category_dic_nms = "", backup = F)
txt <- readtext("kor.txt")
txt0<-strsplit(txt$text,"\n")
txt1=txt0[[1]]


loc<-grep("[[0-9]]",txt1)
sname=txt1[loc+1]
loc1<-loc+3
loc2<-loc[-1]-1
loc2<-c(loc2,length(txt1))

nspeech=length(loc1)
add =list() 
all_txt=""
for (i in 1:nspeech)
{ 
  ind_add=txt1[loc1[i]:loc2[i]]
  add[[i]]=paste(ind_add,collapse=" ")
}

speech_len=nchar(add)






####################################################


ep("[[0-9]]",txt1)
loc1<-loc+3
loc2<-loc[-1]-1
loc2<-c(loc2,length(txt1))
nspeech=length(loc1)

sname=txt1[loc+1]

add =list() 
all_txt=""
for (i in 1:nspeech)
{ 
  ind_add=txt1[loc1[i]:loc2[i]]
  add[[i]]=paste(ind_add,collapse=" ")
  all_txt<-paste(all_txt,ind_add)
}


################ For all address  #################
t<-extractNoun(all_txt)
add_all_to=unlist(t)
t_all=table(add_all_to)
wordcloud(words = names(t_all), freq = t_all, scale=c(8,.3),min.freq = 50, colors=brewer.pal(8, "Dark2"))


############### Comparison among presidents ########################

add_v<-as.matrix(add)
df_t=data.frame(president=sname,address=add_v)

add_w<-lapply(add,extractNoun)

df_t$n_words=lapply(add_w,length)

tt1<-lapply(add_w,table)
tt2<-lapply(tt1,sort, decreasing=T)

p1_freq=tt2[[12]]
p2_freq=tt2[[16]]

nf <- layout(matrix(c(1,2,3,4),2,2,byrow = F), c(4,4), c(0.5,4), F)
layout.show(nf)
par(mar=rep(0, 4))
plot.new()
text(x=0.5, y=0.1, df_t$president[12])
wordcloud(words = names(tt2[[12]]), freq = tt2[[12]], scale=c(8,.3),min.freq = 3, colors=brewer.pal(8, "Dark2"))

plot.new()
text(x=0.5, y=0.1, df_t$president[16])
wordcloud(words = names(tt2[[16]]), freq = tt2[[16]], scale=c(8,.03),min.freq = 3, colors=brewer.pal(8, "Dark2"))


combine<-c(df_t$address[[12]],df_t$address[[16]])
corp = VCorpus(VectorSource(combine))

corp <- tm_map(corp, removePunctuation)
corp <- tm_map(corp, content_transformer(tolower))
corp <- tm_map(corp, removeNumbers)
corp <- tm_map(corp, function(x)removeWords(x,stopwords()))
term.matrix <- TermDocumentMatrix(corp)
term.matrix <- as.matrix(term.matrix)
colnames(term.matrix) <- df_t$president[c(12,16)]
comparison.cloud(term.matrix,max.words=50,random.order=FALSE,title.size=1)
commonality.cloud(term.matrix,max.words=100,random.order=FALSE)


##############################







t2<-table(add_t[[58]])
dim(t2)
tt2<-sort(t2,decreasing=T)
tt2[1:100]











#=============================================================

t1<-scan("psysoc.txt", what="character",sep=c(".","\n","?"))
txt<-t1[t1 !=""]
txt<-tolower(txt)
# txt.w<-strsplit(txt,"\\W")

dframe<-data.frame(txt,stringAsFactors = FALSE)
corpus<-Corpus(VectorSource(dframe$txt))
corpus<-tm_map(corpus,removePunctuation)
corpus<-tm_map(corpus, function (x) removeWords(x, stopwords("english")))
corpus<-tm_map(corpus,stemDocument,language="english")
inspect(corpus)

td<-TermDocumentMatrix(corpus)
check<-which(rowSums(as.matrix(td))>1)
td2<-(td[check,])

LSA<-lsa(td,dim=2)
# wd<-LSA$tk
# st<-LSA$dk
# mg<-LSA$sk
rmat<-LSA$tk%*%diag(LSA$sk)%*%t(LSA$dk)
# sum(abs(as.matrix(td)-rmat))

P<-LSA$tk%*%diag(LSA$sk)
gdf<-data.frame(P)
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text()+xlim(c(0,1.1))
sim1<-cosine(t(wd))
write.csv(sim1,file="t.csv")

t<-which(LSA$X1>6)

P<-LSA$dk%*%diag(LSA$sk)
sub<-c(rep(1,13), rep(2,12))
gdf<-data.frame(sub,P)
ggplot(gdf)+aes(x=X1,y=X2,color=sub,label=rownames(gdf))+geom_text()


########### remove sparce words ###################
LSA<-lsa(td2,dim=2)
# wd<-LSA$tk
# st<-LSA$dk
# mg<-LSA$sk
P<-LSA$tk%*%diag(LSA$sk)
gdf<-data.frame(P)
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text()
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text(size=6)+xlim(-2,0)+ylim(-0.5,2.3)


P<-LSA$dk%*%diag(LSA$sk)
sub<-c(rep(1,13), rep(2,12))
gdf<-data.frame(sub,P)
ggplot(gdf)+aes(x=X1,y=X2,color=sub,label=rownames(gdf))+geom_text()


######################################

dtmo1 <- DocumentTermMatrix(corpus, control = list(wordLengths=c(2,Inf), weighting=weightTf))
dtmo2 <- removeSparseTerms(dtmo1, sparse=0.85)
dtm <- dtmo2

rowTotals <- apply(dtm, 1, sum)
dtm2 <- dtm[rowTotals>0,]
dtm_LDA <- LDA(dtm2, 2)



#lda.collapsed.gibbs.sampler(td2, 3,vocab)



