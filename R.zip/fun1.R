

descrpt <- function(x,n){
  minx = min(x)
  minxi =which.min(x)
  maxx = max(x)
  maxxi = which.max(x)
  result=list(minxi,maxxi)
  cat("Minimum Length = ", minx,  "index = ", minxi, "     ",n[minxi], "\n")
  cat("Maxmum Length = ", maxx,  "index = ", maxxi, "     ",n[maxxi], "\n")
  cat("Mean Length = ", mean(x),  "  Standard Devidation = ", sd(x), "\n")
  
  return(result)
}


token_des<-descrpt(df_t$n_words, sname)
type_des<-descrpt(df_t$n_types, sname)
