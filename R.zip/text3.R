rm(list=ls())

library(readtext)
library(tm)
library(stringr)
library(ggplot2)
library(tokenizers)
library(wordcloud)

txt <- readtext("usa.txt")
txt0<-strsplit(txt$text,"\n")
txt1=txt0[[1]]


loc<-grep("[[0-9]]",txt1)
sname=txt1[loc+1]
loc1<-loc+3
loc2<-loc[-1]-1
loc2<-c(loc2,length(txt1))

nspeech=length(loc1)
add =list() 
all_txt=""
for (i in 1:nspeech)
{ 
  ind_add=txt1[loc1[i]:loc2[i]]
  add[[i]]=paste(ind_add,collapse=" ")
}

speech_len=nchar(add)
hist(speech_len)
library(psych)
describe(speech_len,skew=F)


sname[which(speech_len==791)]
sname[which(speech_len==49702)]





################ For all address  #################
all_txt=toString(add)
add_all_to=unlist(tokenize_words(all_txt))
t_all=table(add_all_to)

wordcloud(words = names(t_all), freq = t_all, scale=c(7,.3),min.freq = 50, colors=brewer.pal(8, "Dark2"))

add_all_to_st=unlist(tokenize_words(all_txt,stopwords=stopwords("english")))
t_all_st=table(add_all_to_st)
wordcloud(words = names(t_all_st), freq = t_all_st, scale=c(5,0.3),min.freq = 100, colors=brewer.pal(8, "Dark2"))



############### Comparison among presidents ########################
df_t=data.frame(president=sname,address=as.matrix(add))
df_t$n_words=count_words(df_t$address)

add_to=tokenize_words(add,stopwords("english"),lowercase=T)

tt1<-lapply(add_to,table)
tt2<-lapply(tt1,sort, decreasing=T)

tt2[[1]][1:10]
tt2[[56]][1:10]
tt2[[58]][1:10]


n_types=lapply(tt1,length)
df_t$n_types=as.numeric(n_types)



descrpt <- function(x,n){
  minx = min(x)
  minxi =which.min(x)
  maxx = max(x)
  maxxi = which.max(x)
  cat("Minimum Length = ", minx,  "index = ", minxi, "     ",n[minxi], "\n")
  cat("Maximum Length = ", maxx,  "index = ", maxxi, "     ",n[maxxi], "\n")
  cat("Mean Length = ", mean(x),  "  Standard Deviation = ", sd(x), "\n")
  
  result=list(min_index=minxi,max_idex=maxxi)
  
  return(result)
}


token_des<-descrpt(df_t$n_words, sname)
type_des<-descrpt(df_t$n_types, sname)


indx1=58
indx2=56

p1_freq=tt2[[indx1]]   # Trump 
p2_freq=tt2[[indx2]]   # Obama 

nf <- layout(matrix(c(1,2,3,4),2,2,byrow = F), c(4,4), c(0.5,4))
layout.show(nf)
par(mar=rep(0, 4))
plot.new()
text(x=0.5, y=0.1, df_t$president[indx1])
wordcloud(words = names(tt2[[indx1]]), freq = tt2[[indx1]], min.freq = 2, colors=brewer.pal(8, "Dark2"))

plot.new()
text(x=0.5, y=0.1, df_t$president[indx2])
wordcloud(words = names(tt2[[indx2]]), freq = tt2[[indx2]], min.freq = 2, colors=brewer.pal(8, "Dark2"))

par(mfrow = c(1,1))

p1_freq["us"]
p2_freq["us"]
p1_freq[c("america","american")]
p2_freq[c("america","american")]


############################################################################

txt<-df_t$address
txt<- gsub("[^[:graph:]]"," ",txt)
txt <- gsub("[[:punct:]]"," ",txt)

corpus<-VCorpus(VectorSource(txt))
corpus <- tm_map(corpus, content_transformer(tolower))
corpus<-tm_map(corpus,content_transformer(removePunctuation))
corpus<-tm_map(corpus, function (x) removeWords(x, stopwords("english")))
corpus<-tm_map(corpus,content_transformer(stemDocument),language="english")

inspect(corpus)

td<-TermDocumentMatrix(corpus)
td_matrix=as.matrix(td)
td_matrix[c(230:240,677,5140),40:58]


findFreqTerms(td, 150)
findAssocs(td, "job", 0.7)

dfg<-data.frame(word=names(t$job),assoc=t$job)

ggplot(data=dfg, aes(x=word, y=assoc)) + geom_bar(stat="identity")+coord_flip()


#inspect(removeSparseTerms(td, 0.8))


combine<-c(df_t$address[[58]],df_t$address[[20]],df_t$address[[44]])

corp = VCorpus(VectorSource(combine))

corp <- tm_map(corp, content_transformer(removePunctuation))
corp <- tm_map(corp, content_transformer(tolower))
corp <- tm_map(corp, content_transformer(removeNumbers))
corp <- tm_map(corp, function(x)removeWords(x,stopwords()))
corp <- tm_map(corp, content_transformer(stemDocument),language="english")
term.matrix <- TermDocumentMatrix(corp)
term.matrix <- as.matrix(term.matrix)
#colnames(term.matrix) <- df_t$president[c(indx1,indx2,20)]
colnames(term.matrix) <- c("TRUMP","LICOLN","KENNEDY")


comparison.cloud(term.matrix,max.words=100,random.order=FALSE,title.size=1)
commonality.cloud(term.matrix,comonality.measure=max,random.order=FALSE)


##############################
t2<-table(add_t[[58]])
dim(t2)
tt2<-sort(t2,decreasing=T)
tt2[1:100]

###############################









#=============================================================

data_t <- t(as.matrix(td))
row.names(data_t)<-sname
d <- dist(data_t, method = "euclidean") # distance matrix
fit <- hclust(d, method="ward.D") 
plot(fit) # display dendogram
groups <- cutree(fit, k=3) # cut tree into 5 clusters
# draw dendogram with red borders around the 5 clusters 
rect.hclust(fit, k=2, border="red")






library(lsa)
LSA<-lsa(td,dim=2)
# wd<-LSA$tk
# st<-LSA$dk
# mg<-LSA$sk
rmat<-LSA$tk%*%diag(LSA$sk)%*%t(LSA$dk)
# sum(abs(as.matrix(td)-rmat))











P<-LSA$tk%*%diag(LSA$sk)
gdf<-data.frame(P)
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text()+xlim(c(0,1.1))
sim1<-cosine(t(wd))
write.csv(sim1,file="t.csv")

t<-which(LSA$X1>6)

P<-LSA$dk%*%diag(LSA$sk)
sub<-c(rep(1,13), rep(2,12))
gdf<-data.frame(sub,P)
ggplot(gdf)+aes(x=X1,y=X2,color=sub,label=rownames(gdf))+geom_text()


########### remove sparce words ###################
LSA<-lsa(td2,dim=2)
# wd<-LSA$tk
# st<-LSA$dk
# mg<-LSA$sk
P<-LSA$tk%*%diag(LSA$sk)
gdf<-data.frame(P)
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text()
ggplot(gdf)+aes(x=X1,y=X2,label=rownames(gdf))+geom_point()+geom_text(size=6)+xlim(-2,0)+ylim(-0.5,2.3)


P<-LSA$dk%*%diag(LSA$sk)
sub<-c(rep(1,13), rep(2,12))
gdf<-data.frame(sub,P)
ggplot(gdf)+aes(x=X1,y=X2,color=sub,label=rownames(gdf))+geom_text()


######################################

dtmo1 <- DocumentTermMatrix(corpus, control = list(wordLengths=c(2,Inf), weighting=weightTf))
dtmo2 <- removeSparseTerms(dtmo1, sparse=0.85)
dtm <- dtmo2

rowTotals <- apply(dtm, 1, sum)
dtm2 <- dtm[rowTotals>0,]
dtm_LDA <- LDA(dtm2, 2)



#lda.collapsed.gibbs.sampler(td2, 3,vocab)



